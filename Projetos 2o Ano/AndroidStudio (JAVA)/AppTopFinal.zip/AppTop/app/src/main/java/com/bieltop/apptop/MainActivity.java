package com.bieltop.apptop;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.lang.reflect.Array;

public class MainActivity extends AppCompatActivity {


    private EditText editTextNome, editTextCodTrab, editTextEmail, editTextTelefone;
    private Button btnEnviar, btnLimpar;
    private Spinner ec, func;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNome = (EditText) findViewById(R.id.edtNome);
        editTextCodTrab = (EditText) findViewById(R.id.edtCodTrab);
        editTextEmail= (EditText) findViewById(R.id.edtEmail);
        editTextTelefone = (EditText) findViewById(R.id.edtTelefone);
        btnEnviar = (Button) findViewById(R.id.btnEnviar);
        btnLimpar = (Button) findViewById(R.id.btnLimpar);


        String[] opcEc = {"Selecione","Solteiro","Casado", "Divorciado", "Viúvo", "Outro"};
        ec = findViewById(R.id.spEc);
        ArrayAdapter<String> adpEc = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item, opcEc);
        ec.setAdapter(adpEc);

        func = findViewById(R.id.spFunc);
        String[] opcFunc = {"Selecione","Administrador","Contador","Zelador","Desenvolvedor"};
        ArrayAdapter<String> adpFunc = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,opcFunc);
        adpFunc.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        func.setAdapter(adpFunc);

        ActionBar bar = getSupportActionBar();
        bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#000000")));


    }



    public void enviar (View view){

        Intent intent = new Intent(MainActivity.this, ValoresActivity.class);

        intent.putExtra("chaveNome",editTextNome.getText().toString());
        intent.putExtra("chaveCodTrab",editTextCodTrab.getText().toString());
        intent.putExtra("chaveEmail",editTextEmail.getText().toString());
        intent.putExtra("chaveTelefone",editTextTelefone.getText().toString());
        intent.putExtra("chaveEstadoCivil",ec.getSelectedItem().toString());
        intent.putExtra("chaveFuncao",func.getSelectedItem().toString());




        startActivity(intent);
        finish();
    }


    public void limpar (View view){
        editTextNome.setText("");
        editTextCodTrab.setText("");
        editTextEmail.setText("");
        editTextTelefone.setText("");
        ec.setSelection(0);
        func.setSelection(0);
    }
}
