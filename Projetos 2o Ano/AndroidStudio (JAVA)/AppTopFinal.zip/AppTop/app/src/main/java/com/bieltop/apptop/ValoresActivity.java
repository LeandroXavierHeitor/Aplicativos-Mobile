package com.bieltop.apptop;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ValoresActivity extends AppCompatActivity {

    private TextView valorNome, valorCodTrab, valorEstadoCivil, valorTelefone, valorFuncao, valorEmail;
    private Button btnConfirmar, btnCancelar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_valores);

        valorNome = findViewById(R.id.txvValorNome);
        valorCodTrab = findViewById(R.id.txvValorCodTrab);
        valorEstadoCivil = findViewById(R.id.txvValorEstadoCivil);
        valorTelefone = findViewById(R.id.txvValorTelefone);
        valorFuncao = findViewById(R.id.txvValorFuncao);
        valorEmail = findViewById(R.id.txvValorEmail);
        btnConfirmar = findViewById(R.id.btnConfirmar);
        btnCancelar = findViewById(R.id.btnCancelar);

        String nome = getIntent().getStringExtra("chaveNome");
        String trabalho = getIntent().getStringExtra("chaveCodTrab");
        String email = getIntent().getStringExtra("chaveEmail");
        String telefone = getIntent().getStringExtra("chaveTelefone");
        String estadoCivil = getIntent().getStringExtra("chaveEstadoCivil");
        String funcao = getIntent().getStringExtra("chaveFuncao");

        valorNome.setText(nome);
        valorCodTrab.setText(trabalho);
        valorEstadoCivil.setText(estadoCivil);
        valorTelefone.setText(telefone);
        valorFuncao.setText(funcao);
        valorEmail.setText(email);

        ActionBar bar = getSupportActionBar();
        bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#000000")));

    }

    public void confirmar (View view){
        Intent intent = new Intent(ValoresActivity.this,ConfirmouActivity.class);
        startActivity(intent);
        finish();
    }

    public void cancelar (View view){
        valorNome.setText("");
        valorCodTrab.setText("");
        valorEstadoCivil.setText("");
        valorTelefone.setText("");
        valorFuncao.setText("");
        valorEmail.setText("");

        Intent intent = new Intent(ValoresActivity.this,MainActivity.class);
        startActivity(intent);
        finish();
    }

    




}






