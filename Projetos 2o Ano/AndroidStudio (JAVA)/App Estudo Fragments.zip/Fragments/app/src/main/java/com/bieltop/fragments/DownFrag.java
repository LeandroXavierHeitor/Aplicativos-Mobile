package com.bieltop.fragments;

import android.app.Activity;
import android.app.AliasActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class DownFrag extends Fragment {

    View rootview;
   TextView res;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootview =  inflater.inflate(R.layout.frag_baixo,container,false);
        res = rootview.findViewById(R.id.res);
        Bundle bundle = new Bundle();
        if(bundle!=null) {
            bundle = getArguments();
            res.setText("");


            String a;

        a = bundle.getString("x1");
            res.setText(a);
        }
        else{
            System.out.println("Deu merda no bundle");
        }
/*        if(bundle.getString("x1") == null && bundle.getString("x2") == null){
            Double a = bundle.getDouble("delta");
            res.setText("Delta = "+a+
                    "\nx1 e x2 são do conjunto vazio" );
        }else if(bundle.getString("x1") != null && bundle.getString("x2")!= null){
            Double a = bundle.getDouble("delta");
            String x1 = bundle.getString("x1");
            String x2 = bundle.getString("x2");
            res.setText("x1: "+x1+"\n" +
                            "x2: "+x2+"\n" +
                    "Delta: "+a);
        }else{
            Double a = bundle.getDouble("delta");
            String x1 = bundle.getString("x1");
            String x2 = bundle.getString("x2");
            res.setText("x1: "+x1+"\n" +
                    "x2: "+x2+"\n" +
                    "Delta: "+a);
        }*/

        return rootview;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }



}
