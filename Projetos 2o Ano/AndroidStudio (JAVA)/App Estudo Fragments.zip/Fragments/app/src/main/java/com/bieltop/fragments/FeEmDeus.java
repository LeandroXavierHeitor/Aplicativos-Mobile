package com.bieltop.fragments;

public interface FeEmDeus {
    void onSetText(String str);
}
