package com.bieltop.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.text.DecimalFormat;

import static java.lang.Double.valueOf;

public class UpFrag extends Fragment {


    View rootview;
    Button botao;


    @Nullable
    @Override
    public View onCreateView( LayoutInflater inflater,  ViewGroup container,  Bundle savedInstanceState) {
        rootview =  inflater.inflate(R.layout.frag_cima,container,false);
        botao = (Button) rootview.findViewById(R.id.btnEnviar);
        botao.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                EditText ae = (EditText) getActivity().findViewById(R.id.a);
                EditText be =  (EditText) getActivity().findViewById(R.id.b);
                EditText ce = (EditText) getActivity().findViewById(R.id.c);


               String a,b,c;
                a = ae.getText().toString();
                b = be.getText().toString()  ;
               c =  ce.getText().toString() ;

                DecimalFormat df = new DecimalFormat("0.00");

                Float an;
                Float bn;
                Float cn;
                Float delta;
                double x1;
                double x2;

                an = Float.parseFloat(a);
               bn = Float.parseFloat(b);
               cn = Float.parseFloat(c);



                delta = ((bn*bn)-(4*an*cn));

                if(delta>0){
                    x1 = (-bn-Math.sqrt(delta))/(2*an);
                    x2 = ((-bn+Math.sqrt(delta))/(2*an));
                    DownFrag fragment = new DownFrag();
                    Bundle bundle = new Bundle();
                    x1 = Double.parseDouble((String)df.format(x1));

                    bundle.putString("x1",String.valueOf(x1));
                    x2 = Double.parseDouble((String)df.format(x2));
                    bundle.putString("x1",String.valueOf(x2));
                    fragment.setArguments(bundle);


                }else if(delta==0){
                    x1 = ((-bn-Math.sqrt(delta))/(2*an));
                    DownFrag fragment = new DownFrag();
                    Bundle bundle = new Bundle();
                    x1 = Double.parseDouble((String)df.format(x1));
                    bundle.putString("x1",String.valueOf(x1));
                    fragment.setArguments(bundle);
                }else{
                    DownFrag fragment = new DownFrag();
                    Bundle bundle = new Bundle();

                    bundle.putString("x",null);
                    bundle.putDouble("delta",delta);
                    fragment.setArguments(bundle);
                }
            }
        });

        return rootview;
    }




}
