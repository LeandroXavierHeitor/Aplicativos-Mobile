package com.leandrel.seg_e_pent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class Tela1 extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela1);
    }


    public void home(View view) {

        //Intent iHome = new Intent(this, primeiraTela.class); ******** ARRUMA AQUI LEANDROOOOOO******
        //startActivity(iHome);


    }
    public void prox(View view){
        Intent iProx = new Intent(this, Tela2.class);
        startActivity(iProx);
    }


}
