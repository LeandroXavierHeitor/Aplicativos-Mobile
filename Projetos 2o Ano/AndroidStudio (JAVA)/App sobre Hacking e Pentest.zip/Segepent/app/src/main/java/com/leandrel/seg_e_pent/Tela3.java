package com.leandrel.seg_e_pent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Tela3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela3);
    }

    public void home(View view) {

        //Intent iHome = new Intent(this, primeiraTela.class); ******** ARRUMA AQUI LEANDROOOOOO******
        //startActivity(iHome);


    }
    public void prox(View view){
        Intent iProx = new Intent(this, Tela4.class);
        startActivity(iProx);
    }
    public void voltar(View view){

        Intent iVoltar = new Intent(this, Tela2.class);
        startActivity(iVoltar);
    }
}
