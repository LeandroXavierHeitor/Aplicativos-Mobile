package com.piton.calculadoradosgenios;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public void sub(View v){
        TextView texto;

        texto = findViewById(R.id.txvResult);
        EditText nmr1 = findViewById(R.id.edtNmr1);
        EditText nmr2 = findViewById(R.id.edtNmr2);
        String num1 = nmr1.getText().toString();
        String num2 = nmr2.getText().toString();
        if(num1.length()==0 || num2.length()<1){
            Toast.makeText(MainActivity.this,"Digite um número válido", Toast.LENGTH_LONG).show();
        }
        else {
            double nm1 = Double.parseDouble(num1);
            double nm2 = Double.parseDouble(num2);

            double result = nm1 - nm2;
            texto.setText("O RESULTADO É: " + result);
        }
    }
    public void soma(View v){
        TextView texto;

        texto = findViewById(R.id.txvResult);
        EditText nmr1 = findViewById(R.id.edtNmr1);
        EditText nmr2 = findViewById(R.id.edtNmr2);
        String num1 = nmr1.getText().toString();
        String num2 = nmr2.getText().toString();
        if(num1.length()==0 || num2.length()<1){
            Toast.makeText(MainActivity.this,"Digite um número válido", Toast.LENGTH_LONG).show();
        }
        else {
            double nm1 = Double.parseDouble(num1);
            double nm2 = Double.parseDouble(num2);

            double result = nm1 + nm2;
            texto.setText("O RESULTADO É: " + result);
        }
    }
    public void mult(View v){
        TextView texto;

        texto = findViewById(R.id.txvResult);
        EditText nmr1 = findViewById(R.id.edtNmr1);
        EditText nmr2 = findViewById(R.id.edtNmr2);
        String num1 = nmr1.getText().toString();
        String num2 = nmr2.getText().toString();
        if(num1.length()==0 || num2.length()<1){
            Toast.makeText(MainActivity.this,"Digite um número válido", Toast.LENGTH_LONG).show();
        }
        else {
            double nm1 = Double.parseDouble(num1);
            double nm2 = Double.parseDouble(num2);

            double result = nm1 * nm2;
            texto.setText("O RESULTADO É: " + result);
        }
    }
    public void div(View v){
        TextView texto;

        texto = findViewById(R.id.txvResult);
        EditText nmr1 = findViewById(R.id.edtNmr1);
        EditText nmr2 = findViewById(R.id.edtNmr2);
        String num1 = nmr1.getText().toString();
        String num2 = nmr2.getText().toString();
        if(num1.length()==0 || num2.length()<1){
            Toast.makeText(MainActivity.this,"Digite um número válido", Toast.LENGTH_LONG).show();
        }
        else if(num2.equalsIgnoreCase("0")){
            Toast.makeText(MainActivity.this,"Impossível dividir por 0", Toast.LENGTH_LONG).show();

        }
        else {
            double nm1 = Double.parseDouble(num1);
            double nm2 = Double.parseDouble(num2);

            double result = nm1 / nm2;
            texto.setText("O RESULTADO É: " + result);
        }
    }
    public void limpar (View v){
        TextView texto;
        texto = findViewById(R.id.txvResult);
        EditText nmr1, nmr2;
        nmr1 = findViewById(R.id.edtNmr1);
        nmr2 = findViewById(R.id.edtNmr2);
        nmr2.setText("");
        nmr1.setText("");
        texto.setText("");
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);




    }


}